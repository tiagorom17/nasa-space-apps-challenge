package com.qpa.alg;

class AppBarConfiguration {
}
