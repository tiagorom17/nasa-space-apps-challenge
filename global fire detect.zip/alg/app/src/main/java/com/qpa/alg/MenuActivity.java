package com.qpa.alg;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MenuActivity extends FragmentActivity implements OnMapReadyCallback {


    private GoogleMap map;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        checkPermission(Manifest.permission.ACCESS_FINE_LOCATION, 100);

    }


    public void checkPermission(String permission, int requestCode) {
        // Checking if permission is not granted
        if (ContextCompat.checkSelfPermission(MenuActivity.this, permission) == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(MenuActivity.this, new String[] { permission }, requestCode);
        }
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        map = googleMap;

        //Algas
        LatLng varese = new LatLng(-32.216513,-65.045914);
        map.addMarker(new MarkerOptions().position(varese).title("Cuartel de Tanti").snippet("bomberos").icon(BitmapDescriptorFactory.fromResource(R.drawable.alga)));
        LatLng madryn = new LatLng(-34.660696,-58.627942);
        map.addMarker(new MarkerOptions().position(madryn).title("Cuartel de Moron").snippet("Bomberos").icon(BitmapDescriptorFactory.fromResource(R.drawable.alga)));
        LatLng Gesell = new LatLng(-31.478720,-64.237592);
        map.addMarker(new MarkerOptions().position(Gesell).title("Cuartel 5° Cordoba").snippet("Bomberos").icon(BitmapDescriptorFactory.fromResource(R.drawable.alga)));
        LatLng quilmes = new LatLng(-34.730147,-58.254235);
        map.addMarker(new MarkerOptions().position(quilmes).title("Cuartel de bomberos de Quilmes").snippet("Bomberos").icon(BitmapDescriptorFactory.fromResource(R.drawable.alga)));




        //Medusas
        LatLng santaclara = new LatLng(-24.747407,-58.408538);
        map.addMarker(new MarkerOptions().position(santaclara).title("sub urbano Ninfa").snippet("Zona ya incendiada").icon(BitmapDescriptorFactory.fromResource(R.drawable.fueguito_amarillo)));


        //Pesca
        LatLng GolfoSJ = new LatLng(-46,-67);
        map.addMarker(new MarkerOptions().position(GolfoSJ).title("Golfo San Jorge").snippet("Zona de poca probabilidad de incendio").icon(BitmapDescriptorFactory.fromResource(R.drawable.safe)));
        LatLng BahiaBlanca = new LatLng(-38.81243509046627,-62.22479452345115);
        map.addMarker(new MarkerOptions().position(BahiaBlanca).title("Bahia Blanca").snippet("Zona de poca probabilidad de incendio").icon(BitmapDescriptorFactory.fromResource(R.drawable.safe)));
        LatLng ushuaia = new LatLng(-54.861120,-68.188360);
        map.addMarker(new MarkerOptions().position(ushuaia).title("Canal de Beagle").snippet("Zona de poca probabilidad de incendio").icon(BitmapDescriptorFactory.fromResource(R.drawable.safe)));



        //Playita
        LatLng SanBer = new LatLng(-31.368108,-64.581891);
        map.addMarker(new MarkerOptions().position(SanBer).title("Tanti").snippet("Alerta de incendio").icon(BitmapDescriptorFactory.fromResource(R.drawable.rojo)));
        LatLng Pinamar = new LatLng(-37.11276260366418,-56.850013440952225);
        map.addMarker(new MarkerOptions().position(Pinamar).title("Pinamar").snippet("Zona probable de incendios").icon(BitmapDescriptorFactory.fromResource(R.drawable.war)));
        LatLng Lastoninas = new LatLng(-36.481649,-56.704216);
        map.addMarker(new MarkerOptions().position(Lastoninas).title("Las Toninas").snippet("Zona probable de incendios").icon(BitmapDescriptorFactory.fromResource(R.drawable.war)));
        LatLng hospital = new LatLng(-31.427557,-64.168224);
        map.addMarker(new MarkerOptions().position(hospital).title("Hospital San Roque").snippet("Hospital").icon(BitmapDescriptorFactory.fromResource(R.drawable.clinica)));
        LatLng hospi = new LatLng(-34.651381,-58.617201);
        map.addMarker(new MarkerOptions().position(hospi).title("Clinica modelo de Moron").snippet("Hospital").icon(BitmapDescriptorFactory.fromResource(R.drawable.clinica)));




        //Setup
        setUpMap();
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(varese, 15));
    }

    public void setUpMap() {
        map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        map.setMyLocationEnabled(true);
    }
}
